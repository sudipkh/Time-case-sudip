package com.time;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorldTimezoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorldTimezoneApplication.class, args);
	}

}
