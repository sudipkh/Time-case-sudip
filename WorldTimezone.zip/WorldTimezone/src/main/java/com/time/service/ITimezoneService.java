package com.time.service;

import com.time.model.TimeZoneModel;

public interface ITimezoneService {
	
	public TimeZoneModel getTimeZoneDetails(String timezone);

}
